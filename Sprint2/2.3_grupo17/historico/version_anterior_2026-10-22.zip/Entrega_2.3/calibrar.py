"""Calibracion de la camara con las fotos del tablero de ajedrez."""

from pathlib import Path

import cv2
import numpy as np


CARPETA = Path(__file__).resolve().parent
FOTOS = CARPETA / "Fotos_Sprint2_2.3"
SALIDA = CARPETA / "calibracion_jetbot.yml"
PATRON = (13, 9)  # Esquinas interiores del tablero


def buscar_esquinas(gris):
    # Primero buscamos en pequeño para tardar menos.
    pequena = cv2.resize(gris, None, fx=0.5, fy=0.5)
    ok, esquinas = cv2.findChessboardCornersSB(
        pequena, PATRON, flags=cv2.CALIB_CB_NORMALIZE_IMAGE
    )
    if ok:
        esquinas *= 2
        cv2.cornerSubPix(
            gris, esquinas, (5, 5), (-1, -1),
            (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 40, 0.001),
        )
        return esquinas

    # Si no aparece, intentamos con la foto original.
    ok, esquinas = cv2.findChessboardCornersSB(
        gris, PATRON, flags=cv2.CALIB_CB_NORMALIZE_IMAGE
    )
    return esquinas if ok else None


fotos = sorted(FOTOS.glob("*.jpg"))
if not fotos:
    raise SystemExit(f"No hay fotos en {FOTOS}")

# Coordenadas de las 117 esquinas: cada casilla vale una unidad.
puntos_tablero = np.zeros((PATRON[0] * PATRON[1], 3), np.float32)
puntos_tablero[:, :2] = np.mgrid[0:13, 0:9].T.reshape(-1, 2)

detectadas = []
tamano = None
for foto in fotos:
    gris = cv2.imread(str(foto), cv2.IMREAD_GRAYSCALE)
    if gris is None:
        continue
    tamano = (gris.shape[1], gris.shape[0])
    esquinas = buscar_esquinas(gris)
    if esquinas is not None:
        detectadas.append((foto, esquinas))
        print("Tablero encontrado:", foto.name)

if len(detectadas) < 8:
    raise SystemExit("Hay muy pocas fotos con el tablero completo para calibrar.")

# Quitamos las fotos cuyo ajuste supera 3 pixeles y recalculamos.
usadas = detectadas[:]
for _ in range(5):
    objetos = [puntos_tablero.copy() for foto, esquinas in usadas]
    imagenes = [esquinas for foto, esquinas in usadas]
    rms, K, D, rotaciones, traslaciones = cv2.calibrateCamera(
        objetos, imagenes, tamano, None, None, flags=cv2.CALIB_FIX_K3
    )
    errores = []
    for obj, esquinas, rot, tras in zip(objetos, imagenes, rotaciones, traslaciones):
        calculadas, _ = cv2.projectPoints(obj, rot, tras, K, D)
        error = np.sqrt(np.mean(np.sum((esquinas - calculadas) ** 2, axis=2)))
        errores.append(error)
    buenas = [par for par, error in zip(usadas, errores) if error <= 3.0]
    if len(buenas) == len(usadas) or len(buenas) < 8:
        break
    usadas = buenas

# OpenCV guarda la matriz y la distorsion en un fichero YAML.
archivo = cv2.FileStorage(str(SALIDA), cv2.FILE_STORAGE_WRITE)
archivo.write("image_width", tamano[0])
archivo.write("image_height", tamano[1])
archivo.write("camera_matrix", K)
archivo.write("distortion_coefficients", D)
archivo.write("reprojection_rms", float(rms))
archivo.write("pattern_inner_corners_x", PATRON[0])
archivo.write("pattern_inner_corners_y", PATRON[1])
archivo.write("square_size", 1.0)
archivo.write("usable_image_count", len(usadas))
archivo.release()

print(f"\nFotos: {len(fotos)}; tablero detectado: {len(detectadas)}; usadas: {len(usadas)}")
print(f"Error RMS: {rms:.4f} pixeles")
print("Calibracion guardada en:", SALIDA)
