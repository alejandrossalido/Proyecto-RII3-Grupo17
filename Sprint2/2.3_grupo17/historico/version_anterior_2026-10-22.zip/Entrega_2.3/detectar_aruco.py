"""Pasa las fotos una a una y muestra el ID y los ejes de cada ArUco."""

from pathlib import Path

import cv2
import numpy as np


CARPETA = Path(__file__).resolve().parent
FOTOS = sorted((CARPETA / "Fotos_Sprint2_2.3").glob("*.jpg"))
CALIBRACION = CARPETA / "calibracion_jetbot.yml"
RESULTADOS = CARPETA / "resultados"
RESULTADOS.mkdir(exist_ok=True)
if not FOTOS:
    raise SystemExit("No se encontraron las fotos del Sprint 2")

datos = cv2.FileStorage(str(CALIBRACION), cv2.FILE_STORAGE_READ)
if not datos.isOpened():
    raise SystemExit("Primero ejecuta calibrar.py para crear el .yml")
K = datos.getNode("camera_matrix").mat()
D = datos.getNode("distortion_coefficients").mat()
datos.release()

# En estas fotos los codigos pertenecen a la familia 4x4_50.
diccionario = cv2.aruco.Dictionary_get(cv2.aruco.DICT_4X4_50)
parametros = cv2.aruco.DetectorParameters_create()

# Empezamos por una foto que tiene tres marcadores para que se vea bien la demo.
ejemplo = "WIN_20260924_15_12_32_Pro.jpg"
indice = next((i for i, foto in enumerate(FOTOS) if foto.name == ejemplo), 0)

ventana = "ArUco - pasar fotos"
cv2.namedWindow(ventana, cv2.WINDOW_NORMAL)
cv2.resizeWindow(ventana, 1280, 720)

while True:
    foto = FOTOS[indice]
    imagen = cv2.imread(str(foto))
    esquinas, identificadores, descartados = cv2.aruco.detectMarkers(
        imagen, diccionario, parameters=parametros
    )
    ids = [] if identificadores is None else identificadores.flatten().tolist()

    if ids:
        cv2.aruco.drawDetectedMarkers(imagen, esquinas)
        # Una unidad equivale al lado del ArUco. Solo necesitamos su orientacion.
        rotaciones, traslaciones, _ = cv2.aruco.estimatePoseSingleMarkers(
            esquinas, 1.0, K, D
        )
        for esquina, id_aruco, rot, tras in zip(esquinas, ids, rotaciones, traslaciones):
            cv2.drawFrameAxes(imagen, K, D, rot, tras, 0.55, 3)
            x = int(np.min(esquina[0, :, 0]))
            y = int(np.min(esquina[0, :, 1]))
            x = min(max(x, 5), imagen.shape[1] - 120)
            y = max(y - 55, 5)
            cv2.rectangle(imagen, (x, y), (x + 112, y + 38), (16, 23, 39), -1)
            cv2.putText(imagen, f"ID {id_aruco}", (x + 7, y + 28),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 255, 255), 2)

    # Informacion para pasar por las fotos durante la presentacion.
    cv2.rectangle(imagen, (0, 0), (imagen.shape[1], 90), (12, 22, 39), -1)
    cv2.putText(imagen, f"Foto {indice + 1}/{len(FOTOS)}: {foto.name}   IDs: {ids}",
                (22, 39), cv2.FONT_HERSHEY_SIMPLEX, 0.85, (255, 255, 255), 2)
    cv2.putText(imagen, "ESPACIO/N: siguiente    P: anterior    Q: salir",
                (22, 76), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (200, 225, 245), 2)
    if foto.name == ejemplo:
        cv2.imwrite(str(RESULTADOS / "aruco_ids_y_ejes.jpg"), imagen)
    print(f"Foto {indice + 1}/{len(FOTOS)}: {foto.name} -> IDs {ids}", flush=True)

    cv2.imshow(ventana, imagen)
    tecla = cv2.waitKeyEx(0)
    if tecla in (ord("q"), ord("Q"), 27):
        break
    if tecla in (ord("p"), ord("P")):
        indice = (indice - 1) % len(FOTOS)
    elif tecla in (ord("n"), ord("N"), 32):
        indice = (indice + 1) % len(FOTOS)

cv2.destroyAllWindows()
