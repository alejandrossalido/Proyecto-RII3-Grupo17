"""Corrige una foto y la compara con su version original."""

from pathlib import Path

import cv2
import numpy as np


CARPETA = Path(__file__).resolve().parent
FOTO = CARPETA / "Fotos_Sprint2_2.3" / "WIN_20260924_15_09_04_Pro.jpg"
CALIBRACION = CARPETA / "calibracion_jetbot.yml"
RESULTADOS = CARPETA / "resultados"
RESULTADOS.mkdir(exist_ok=True)

datos = cv2.FileStorage(str(CALIBRACION), cv2.FILE_STORAGE_READ)
if not datos.isOpened():
    raise SystemExit("Primero ejecuta calibrar.py para crear el .yml")
K = datos.getNode("camera_matrix").mat()
D = datos.getNode("distortion_coefficients").mat()
datos.release()

original = cv2.imread(str(FOTO))
if original is None:
    raise SystemExit(f"No se puede abrir {FOTO}")

corregida = cv2.undistort(original, K, D)

izquierda = original.copy()
derecha = corregida.copy()
for imagen, titulo in [(izquierda, "ORIGINAL"), (derecha, "RECTIFICADA")]:
    cv2.rectangle(imagen, (10, 10), (320, 72), (15, 23, 39), -1)
    cv2.putText(imagen, titulo, (23, 55), cv2.FONT_HERSHEY_SIMPLEX,
                1.2, (255, 255, 255), 2, cv2.LINE_AA)

comparacion = np.hstack((izquierda, derecha))
salida = RESULTADOS / "comparacion_original_rectificada.jpg"
cv2.imwrite(str(salida), comparacion)
print("Comparacion guardada en:", salida)

cv2.namedWindow("Original y rectificada", cv2.WINDOW_NORMAL)
cv2.resizeWindow("Original y rectificada", 1280, 360)
cv2.imshow("Original y rectificada", comparacion)
cv2.waitKey(0)  # Pulsa una tecla para cerrar la ventana.
cv2.destroyAllWindows()
